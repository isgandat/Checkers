﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckersMinimax.Pieces
{
    public enum CheckerPieceType
    {
        RedPawn,
        RedKing,
        BlackPawn,
        BlackKing,
        nullPiece
    }
}
