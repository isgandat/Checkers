﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckersMinimax.Pieces
{
    
    /// Interface for a black piece
    /// </summary>
    public interface IBlackPiece
    {
    }
}
