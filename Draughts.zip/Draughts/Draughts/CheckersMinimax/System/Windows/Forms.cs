﻿namespace System.Windows
{
    internal class Forms
    {
        internal class Label
        {
            public Label()
            {
            }
        }
    }
}